// Welcome message
window.onload = function () {
    alert("Welcome to the Multimedia Entertainment Website!");
};

// Movies button
function goMovies() {
    window.location.href = "movies.html";
}

// Music button
function goMusic() {
    window.location.href = "music.html";
}

// About button
function goAbout() {
    window.location.href = "about.html";
}